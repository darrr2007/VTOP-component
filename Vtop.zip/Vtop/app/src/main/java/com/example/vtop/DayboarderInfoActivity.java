package com.example.vtop;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DayboarderInfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dayboarder_info2);
    }
}