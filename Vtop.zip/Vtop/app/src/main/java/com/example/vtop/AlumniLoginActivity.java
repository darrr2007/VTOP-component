package com.example.vtop;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AlumniLoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alumni_login);
    }
}